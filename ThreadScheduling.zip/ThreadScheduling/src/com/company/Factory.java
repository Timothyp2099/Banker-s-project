package com.company;

//-------------------------------------------------------------------------------------------------
// Factory.java
//
// Factory class that creates the bank and each bank customer
// Usage:  java Factory 10 5 7
// To run: java com/company/Factory infile.txt
//NOTE didn't get it to work.
 import java.io.*;
 import java.util.*;
 import java.util.concurrent.Semaphore;
 import java.io.PrintStream;
 import java.io.File;
 import java.io.FileNotFoundException;
 import static java.lang.Integer.min;


public class Factory {                      //Change this to BankersAlgorithm.java
    static Semaphore mutex = new Semaphore(1);
    static Semaphore issafe_mutex = new Semaphore(1);
    static int[] avail;
    static int[] alloc;
    static int[] max;
    public static int m;     // number of resources
    public static int n;     // number of threads
    static void runSimulation(Bank bank){
        System.out.println("\nBanker's algorithm simulation beginning ... " +
                "\n-------------------------------------------------------");
        bank.getAlloc();
        bank.getMax();
        bank.getNeed();
        bank.requestResources(n, avail);
        bank.releaseResources(n, avail);
    }
    private static void verify(String[] args){
        if (args.length == 0){
            System.err.println("Usage : java bankers filename1");
            System.exit(1);
        }
    }
    public static String strstrip(String s) {
        String t = s.replaceAll("[^a-zA-Z0-9 ]", "");
        return t;
    }
    private static void processLine(String buf, int[] values) {
        buf = strstrip(buf);
        buf = buf.toLowerCase();
        values = null;
        String[] tokens = buf.split("\\s+");
        for (String el : tokens) {
            int val = Integer.parseInt(el);
            values[val] = val;
        }
    }
    private static Bank processFile(String filename) {
        String buf = null;
        int resource = 0;
        int[] res = new int[resource];
        File file =  new File(filename);
        Scanner sc = null;
        Bank bank = null;
        try{
            sc = new Scanner(file);
        } catch(FileNotFoundException e) {
            System.err.println("\n\nWarning, could not open file: '" + filename + "'");
            return null;
        }
        System.out.println("\n\nProcessing file: '" + filename + "'...");
        boolean firstLine = true;
        int idx = 0;
        while (sc.hasNextLine()) {
            buf = sc.nextLine();
            if (buf.length() == 0){
                break;
            }
            processLine(buf, res);
            if (firstLine) {
                avail = new int[m];
              bank = new BankImpl(avail);
              firstLine = false;
            }
            else {
                alloc = new int[m];
                max = new int[m];
                //int size = bank.getAvail().avail.length;
                for (int i = 0; i < avail[m]; i++) {
                    bank.getAlloc();
                    bank.getMax();
                }
                bank.addCustomer(idx++, alloc, max);
            }
        }
        return bank;
    }
    private static void processFiles(String[] args) {
        Bank bank = null;
        for (String filename : args) {
            bank = processFile(filename);

            if (bank.getCustomers().isEmpty()) {
                System.err.println("\t\tNo customers found...exiting...\n\n");
                System.exit(1);
            }
            if (bank == null) {
                System.err.println("\t\tNo customers found...bank = null...\n\n");
                System.exit(1);
            }
            runSimulation(bank);
            System.out.println("\n\n");
        }
    }
    public static void main(String[] args) {
        processFiles(args);
        verify(args);
    }
        /*int nResources = args.length;
        int[] resources = new int[nResources];
        for (int i = 0; i < nResources; i++) { resources[i] = Integer.parseInt(args[i].trim()); }
        Bank theBank = new BankImpl(resources);
        int[] maxDemand = new int[nResources];
        int[] allocated = new int[nResources];
        Thread[] workers = new Thread[Customer.COUNT];      // the customers


        // read in values and initialize the matrices
        // to do
        // ...
        String line;
        try {
            BufferedReader inFile = new BufferedReader(new FileReader("C:\\Users\\HP.LAPTOP-K5C0TFSD\\" +
                    "IdeaProjects\\ThreadScheduling\\" +
                    "src\\com\\company\\infile.txt"));
            int threadNum = 0;
            int resourceNum = 0;
            for (int i = 0; i < Customer.COUNT; i++){
                line = inFile.readLine();
                StringTokenizer tokens = new StringTokenizer(line,",");
                while(tokens.hasMoreTokens()){
                    String token = tokens.nextToken().trim();
                    int amount = Integer.parseInt(token);
                    maxDemand[resourceNum++] = amount;

                }
                workers[threadNum] = new Thread(new Customer(threadNum, maxDemand, theBank));
                theBank.addCustomer(threadNum, allocated, maxDemand);
                ++threadNum;
                //theBank.getCustomer(threadNum);
                resourceNum = 0;
            }
        }
        catch (FileNotFoundException fnfe) { throw new Error("Unable to find file \"C:\\Users\\HP.LAPTOP-K5C0TFSD\\" +
                "IdeaProjects\\ThreadScheduling\\" +
                "src\\com\\company\\infile.txt\"");
        } catch (IOException ioe) { throw new Error("Error processing \"C:\\Users\\HP.LAPTOP-K5C0TFSD\\" +
                "IdeaProjects\\ThreadScheduling\\" +
                "src\\com\\company\\infile.txt\""); }
        System.out.println("FACTORY: created threads");     // start the customers
        for (int i = 0; i < Customer.COUNT; i++) { workers[i].start(); }
        System.out.println("FACTORY: started threads");
    }*/
}

