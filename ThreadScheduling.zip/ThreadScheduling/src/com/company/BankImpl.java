package com.company;
//-------------------------------------------------------------------------------------------------
// BankImpl.java
//
// implementation of the Bank
//

public class BankImpl implements Bank {
    private int n;          // the number of threads in the system
    private int m;          // the number of resources
    private int[] available;    // the amount available of each resource availiable[i]
    private int[][] maximum;    // the maximum demand of each thread
    private int[][] allocation; // the amount currently allocated to each thread
    private int[][] need;       // the remaining needs of each thread


    public void showAllMatrices(int[][] alloc, int[][] max, int[][] need, String msg) {
        // todo
        System.out.printf("%s", msg);
        showMatrix(alloc, "Allocated", "BankUse");
        showMatrix(max, "Maximum", "BankMax");
        showMatrix(need, "Need", "CustomerNeed");

    }

    public void showMatrix(int[][] matrix, String title, String rowTitle) {
        // todo
        System.out.printf("%s\n", title);
        System.out.printf("%s", rowTitle);
        int[][] mat = new int[n][m];
        for (int row = 0; row < mat.length; row++) {

            for (int col = 0; col < mat[row].length; col++) {
                System.out.printf("%5d", mat[row][col]);
            }
            System.out.println();
        }
    }

    private void showVector(int[] vect, String msg) {
        // todo
    }

    public BankImpl(int[] resources) {      // create a new bank (with resources)
        m = resources.length;
        n = Customer.COUNT;
        available = new int[m];             // Initialize resources array
        System.arraycopy(resources,0,available,0,m);
        maximum = new int[Customer.COUNT][];                // Arrays for
        allocation = new int[Customer.COUNT][];             // Storing
        need = new int[Customer.COUNT][];                   // max Demand

    }

    // invoked by a thread when it enters the system;  also records max demand
    public void addCustomer(int threadNum, int[] allocated, int[] maxDemand) {
        maximum[threadNum] = new int[m];
        allocation[threadNum] = new int[m];
        need[threadNum] = new int[m];
        System.arraycopy(maxDemand,0,maximum[threadNum],0,maxDemand.length);
        System.arraycopy(maxDemand,0,need[threadNum],0,maxDemand.length);
    }

    public void getAvail() {        // output state for each thread
        int size = available.length;
        System.out.print("Available = [");
        for (int i = 0; i < m - 1; i++) {
            System.out.print(available[i] + " ");
            System.out.println(available[m - 1] + "]");
        }

    }
    public void getAlloc() {
        System.out.print("\nAllocation = ");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < m - 1; j++) {
                System.out.print(allocation[i][j] + "");
            }
            System.out.print(allocation[i][m - 1] + "]");
        }
    }
    public void getMax() {
        System.out.print("\nMax");
        for (int i = 0; i < n; i++) {
            System.out.print("[");
            for (int j = 0; j < m - 1; j++) {
                System.out.print(maximum[i][j] + "");
            }
            System.out.print(maximum[i][m - 1] + "]");
        }
    }
    public void getNeed() {
        System.out.print("\nNeed");
        for (int i = 0; i < n; i++){
            System.out.print("[");
            for (int j = 0; j < m-1; j++){
                System.out.print(need[i][j] + "");
            }
            System.out.print(need[i][m-1] + "]");
        }
        System.out.println();
    }

    private boolean isSafeState(int threadNum, int[] request) {
        // todo -- actual banker's algorithm
        System.out.print("\nCustomer # " + threadNum + "requesting ");
        for (int i = 0; i < m; i++){
            System.out.print("Avaliable = ");
        }
        for (int i = 0; i < m; i++) {
            System.out.print(available[i] + " ");
        }
        for (int i = 0; i < m; i++){                // checks if I have enough resources
            if (request[i] > available[i]){
                System.err.println("Not enough avaliable resources");
                return false;
            }
        }
        boolean[] canFinish = new boolean[n];
        for (int i = 0; i < n; i++){
            canFinish[i] = false;
        }
        int[] avail = new int[m];
        System.arraycopy(available,0,avail,0,available.length);
        for (int i = 0; i < m; i++){
            avail[i] -= request[i];                     // decrement avail
            need[threadNum][i] -= request[i];           // adjust need and allocation for this thread
            allocation[threadNum][i] += request[i];
        }
        for (int i = 0; i < n; i++){
            for (int j = 0; j < n; j++){                // find a thread that can finish
                if (!canFinish[j]){
                    boolean temp = true;
                    for (int k = 0; k < m; k++) {
                        if(need[j][k] > avail[k]) {
                            temp = false;
                        }
                    }
                    if (temp) {                         // condition for thread finishing
                        canFinish[j] = true;
                        for (int x = 0; x < m; x++){
                            avail[x] += allocation[j][x];
                        }
                    }
                }
            }
        }
        for (int i = 0; i < m; i++) {           // restore value of need and allocation
            need[threadNum][i] += request[i];
            allocation[threadNum][i] -= request[i];
        }
        boolean returnValue = true;             // check if all threads could complete
        for (int i = 0; i < n; i++){
            if (!canFinish[i]) {
                returnValue = false;
                break;
            }
        }
        return returnValue;
    }

    // make request for resources. will block until request is satisfied safely
    public synchronized boolean requestResources(int threadNum, int[] request) {
        if (!isSafeState(threadNum,request)){
            return false;
        }
        for (int i = 0; i < m; i++){
            available[i] -= request[i];
            allocation[threadNum][i] += request[i];
            need[threadNum][i] = maximum[threadNum][i] - allocation[threadNum][i];
        }
        showAllMatrices(allocation,maximum,need, "requesting resources");
        return true;
    }

    public synchronized void releaseResources(int threadNum, int[] release) {
        System.out.print("\nCustomer # " + threadNum + "releasing ");
        for (int i =0; i < m; i++){
            System.out.print(release[i] + " ");
        }
        for (int i = 0;i < m; i++){
            available[i] += release[i];
            allocation[threadNum][i] -= release[i];
            need[threadNum][i] = maximum[threadNum][i] - allocation[threadNum][i];
        }
        System.out.print("Availiable = ");
        for (int i = 0; i < m; i++){
            System.out.print(available[i] + " ");
        }
        System.out.print("Allocated = [");
        for (int i = 0; i < m; i++){
            System.out.print(allocation[threadNum][i] + " ]");
        }
    }
    public ExtVector getCustomers() {
        return null;
    }

}
